
Running the app:
mvn compile exec:java -Dexec.mainClass="app.DrawingApp"

Running tests :
mvn -Dtest=bean.CanvasTest test
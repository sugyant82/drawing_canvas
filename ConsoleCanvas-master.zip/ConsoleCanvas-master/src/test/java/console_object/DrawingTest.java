package console_object;

import exception.DrawException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import console_object.MyDrawingCanvas;

import static org.junit.jupiter.api.Assertions.*;

import javax.print.attribute.TextSyntax;

class DrawingTest {

    @Test
    void testConstructor() {
        MyDrawingCanvas canvas  = new MyDrawingCanvas(20, 4);
        assertEquals(canvas.create(),
        "----------------------\n" +
        "|                    |\n" +
        "|                    |\n" +
        "|                    |\n" +
        "|                    |\n" +
        "----------------------");
    }

    @Test
    void testConstructorException() {
        Executable closureContainingCodeToTest = () -> new MyDrawingCanvas(0, 4);
        assertThrows(DrawException.class, closureContainingCodeToTest);
    }

    @Test
    void testMakeALineException() {
        Executable closureContainingCodeToTest = () -> new MyDrawingCanvas().makeALine(1,2,3,4,'x');
        assertThrows(DrawException.class, closureContainingCodeToTest);
    }

    @Test
    void testMakeALine() {
        MyDrawingCanvas canvas = new MyDrawingCanvas(3,5);
        canvas.makeALine(1, 2, 1, 4, 'x');
        assertEquals(canvas.create(),
        "-----\n" +
            "|   |\n" +
            "|x  |\n" +
            "|x  |\n" +
            "|x  |\n" +
            "|   |\n" +
            "-----");
    }

    @Test
    void testMakeARectangle() {
        MyDrawingCanvas canvas = new MyDrawingCanvas(8,4);
        canvas.makeARectangle(2, 1, 6, 3, 'x');
        assertEquals(canvas.create(),
            "----------\n" +
            "| xxxxx  |\n" +
            "| x   x  |\n" +
            "| xxxxx  |\n" +
            "|        |\n" +
            "----------");
    }

    @Test
    void testFillDrawing() {
        MyDrawingCanvas canvas = new MyDrawingCanvas(8,4);
        canvas.makeARectangle(2, 1, 6, 3, 'x');
        canvas.fillDrawing(3,2, 'o');
        assertEquals(canvas.create(),
    "----------\n" +
            "| xxxxx  |\n" +
            "| xooox  |\n" +
            "| xxxxx  |\n" +
            "|        |\n" +
            "----------");
    }
}
package console_object;

import exception.DrawException;

public class MyDrawingCanvas {
    char[][] canvasHolder;
    int w, h;
    public MyDrawingCanvas(){}
    public MyDrawingCanvas(int w, int h) {
        if(w < 1 || h < 1) {
            throw new DrawException("Canvas width and height can't be 0");
        }
        h+=2;
        w+=2;
        this.w = w;
        this.h = h;
        this.canvasHolder = new char[h][w];
        makeALine(0, 0, this.w-1, 0, '-');
        makeALine(0, this.h-1, this.w-1, this.h-1, '-');
        makeALine(0, 1, 0, this.h-2, '|');
        makeALine(this.w-1, 1, this.w-1, this.h-2, '|');
    }
    public String create() {
        isCanvasCreated();
        StringBuilder strBuilder = new StringBuilder();
        for(int i=0;i<this.h;i++) {
            for(int j=0;j<this.w;j++) {
                strBuilder.append(this.canvasHolder[i][j] == '\u0000'?' ':this.canvasHolder[i][j]);
            }
            strBuilder.append("\n");
        }
        return strBuilder.toString().trim();
    }
    public void makeALine(int x1, int y1, int x2, int y2, char mChar) {
        isCanvasCreated();
        for(int i=y1; i<=y2; i++) {
            for(int j=x1; j<=x2; j++) {
                this.canvasHolder[i][j] = mChar;
            }
        }
    }
    public void makeARectangle(int x1, int y1, int x2, int y2, char mchar) {
        isCanvasCreated();
        makeALine(x1,y1, x2, y1, mchar);
        makeALine(x1,y1, x1, y2, mchar);
        makeALine(x2,y1, x2, y2, mchar);
        makeALine(x1,y2, x2, y2, mchar);
    }
    public void fillDrawing(int x, int y, char mchar) {
        isCanvasCreated();
        if((int)this.canvasHolder[y][x] != 0) {
            return;
        }
        if(x > 0 || x < this.h || y > 0 || y  < this.w) {
            if((int)this.canvasHolder[y][x] == 0)
                this.canvasHolder[y][x] = mchar;
            fillDrawing(x+1,y, mchar);
            fillDrawing(x-1,y, mchar);
            fillDrawing(x,y-1, mchar);
            fillDrawing(x,y+1, mchar);
        }
    }

    private void isCanvasCreated() {
        if(this.canvasHolder == null)
            throw new DrawException("you need to create a canvas first!");
    }
}
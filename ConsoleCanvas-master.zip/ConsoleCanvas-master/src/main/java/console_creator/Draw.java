package console_creator;

import exception.DrawException;
import java.util.Scanner;

import console_object.MyDrawingCanvas;

class Draw {

    MyDrawingCanvas canvas;
    public Draw() {
        canvas = new MyDrawingCanvas();
    }
    public static void main(String[] args) throws NumberFormatException {
        Draw app = new Draw();
        Scanner scan = new Scanner(System.in);
        String command = new String();
        while(!command.equals("Q")) {
            System.out.println("\nEnter command:");
            command = scan.nextLine();
            app.drawing_pen(command);
        }
        System.out.println("Program Exited!");
        scan.close();
    }

    private void drawing_pen(String command) throws NumberFormatException {
        char ch = command.charAt(0);
        String[] cmd;
        /*try {
            switch(ch) {
                case 'C' :
                    cmd = command.split(" ");
                    this.canvas = new Canvas(Integer.parseInt(cmd[1]),Integer.parseInt(cmd[2]));
                    System.out.println(this.canvas.render());
                    break;
                case 'L' :
                    cmd = command.split(" ");
                    this.canvas.drawLine(Integer.parseInt(cmd[1]),Integer.parseInt(cmd[2]),Integer.parseInt(cmd[3]),Integer.parseInt(cmd[4]),'X');
                    System.out.println(this.canvas.render());
                    break;
                case 'R' :
                    cmd = command.split(" ");
                    this.canvas.drawRectangle(Integer.parseInt(cmd[1]),Integer.parseInt(cmd[2]),Integer.parseInt(cmd[3]),Integer.parseInt(cmd[4]),'X');
                    System.out.println(this.canvas.render());
                    break;
                case 'B' :
                    cmd = command.split(" ");
                    this.canvas.bucketFill(Integer.parseInt(cmd[1]),Integer.parseInt(cmd[2]),cmd[3].charAt(0));
                    System.out.println(this.canvas.render());
                    break;
            }*/
        
        try{
        	if (ch == 'C'){
        		cmd = command.split(" ");
                this.canvas = new MyDrawingCanvas(Integer.parseInt(cmd[1]),Integer.parseInt(cmd[2]));
                System.out.println(this.canvas.create());
            }
        	else if(ch == 'L'){
        		cmd = command.split(" ");
                this.canvas.makeALine(Integer.parseInt(cmd[1]),Integer.parseInt(cmd[2]),Integer.parseInt(cmd[3]),Integer.parseInt(cmd[4]),'X');
                System.out.println(this.canvas.create());
            }
        	else if(ch == 'R'){
        		cmd = command.split(" ");
                this.canvas.makeARectangle(Integer.parseInt(cmd[1]),Integer.parseInt(cmd[2]),Integer.parseInt(cmd[3]),Integer.parseInt(cmd[4]),'X');
                System.out.println(this.canvas.create());
            }
        	else if(ch == 'B'){
        		cmd = command.split(" ");
                this.canvas.fillDrawing(Integer.parseInt(cmd[1]),Integer.parseInt(cmd[2]),cmd[3].charAt(0));
                System.out.println(this.canvas.create());
        	}
        	else {
        		throw new ArrayIndexOutOfBoundsException();
        	}
        	
        	
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("\nInvalid command. Try again!!\n");
        } catch (Exception e) {
            System.out.println("\nError Occurred : " + e.getMessage() + "\nPlease try again");
        }
    }
}

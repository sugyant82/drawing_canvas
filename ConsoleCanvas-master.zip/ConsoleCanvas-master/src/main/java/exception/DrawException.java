package exception;

public class DrawException extends RuntimeException{
    public DrawException(String message) {
        super(message);
    }
}
